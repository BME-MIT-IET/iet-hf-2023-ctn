package Modell.Vedofelszereles;

import Modell.TulajdonsagModosito;

/**
 * Valamilyen védelemmel vagy extra tulajdonsággal ruházza fel a viselőjét,
 * mindaddig,amíg a virológus le nem veszi magáról vagy el nem veszti.
 */
public class Vedofelszereles extends TulajdonsagModosito {}

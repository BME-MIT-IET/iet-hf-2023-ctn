package Modell.Palya;

import Logika.Virologus;
import Modell.Anyagok.Anyag;
import Modell.Genetika.GenetikaiKod;
import Modell.Vedofelszereles.Vedofelszereles;

import java.util.*;

//KB UML HELYES!

/**
 *A virológus kísérletére amennyiben rendelkezésre
 * áll, az anyag paraméterben megfogalmazott igénynek megfelelően anyagot ad a
 * virológusnak.
 * */
public class TeruletiElem {
    /**
     * A virológus kísérletére amennyiben rendelkezésre
     * áll, az anyag paraméterben megfogalmazott igénynek megfelelően anyagot ad a
     * virológusnak.
     */
    private Set<Virologus> ittJartak;

    /**
     *A virológus kísérletére amennyiben rendelkezésre
     * áll, az anyag paraméterben megfogalmazott igénynek megfelelően anyagot ad a
     * virológusnak.
     */
    private Set<Virologus> ittLevok;

    /**
     * A virológus kísérletére amennyiben rendelkezésre
     * áll, az anyag paraméterben megfogalmazott igénynek megfelelően anyagot ad a
     * virológusnak.
     */
    Set<TeruletiElem> szomszedok;

    public TeruletiElem(){
        szomszedok = new HashSet<TeruletiElem>();
        ittLevok = new HashSet<Virologus>();
        ittJartak = new HashSet<Virologus>();
    }

    /**
     * A virológus kísérletére amennyiben rendelkezésre
     * áll, az anyag paraméterben megfogalmazott igénynek megfelelően anyagot ad a
     * virológusnak.
     * @param o
     */
    public void vedofelszerelesFelvetele(Vedofelszereles o, Virologus ki) {
        return;
    }

    /**
     * A virológus kísérletére amennyiben rendelkezésre
     * áll, az anyag paraméterben megfogalmazott igénynek megfelelően anyagot ad a
     * virológusnak.
     * @param anyag
     */
    public void anyagokFelvetele(Anyag anyag, Virologus akiAkarja) {
        return;
    }

    /**
     * A virológus kísérletére amennyiben rendelkezésre
     * áll, az anyag paraméterben megfogalmazott igénynek megfelelően anyagot ad a
     * virológusnak.
     * @return
     */
    public GenetikaiKod letapogatas() {
        return null;
    }

    /**
     * az adott virológust elhelyezi saját magán [a terület],
     * tehát bekerül az ittLevok és az ittJartak listába
     * @param belepo
     * @return
     */
    public TeruletiElem belepes(Virologus belepo) {
        ittLevok.add(belepo);
        ittJartak.add(belepo);
        return this;
    }

    /**
     * az adott virológust törli az ittLevok listájából.
     * @param kilepo
     */
    public void kilepes(Virologus kilepo) {
        ittLevok.remove(kilepo);
    }


    public Set<TeruletiElem> getSzomszedok() {
        return szomszedok;
    }

    /**
     * szomszédot ad hozzá az aktuális területi elemhez (a szomszédok listájához)
     * @param uj
     */
    public void addSzomszed(TeruletiElem uj){
        szomszedok.add(uj);
    }
}

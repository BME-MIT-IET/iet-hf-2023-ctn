import Logika.Virologus;
import Modell.Agensek.*;
import Modell.Anyagok.Aminosav;
import Modell.Anyagok.Anyag;
import Modell.Anyagok.AnyagTarolo;
import Modell.Anyagok.Nukleotid;
import Modell.Genetika.GenetikaiKod;
import Modell.Palya.*;
import Modell.Vedofelszereles.*;
import Modell.TulajdonsagModosito;

import java.awt.desktop.ScreenSleepEvent;
import java.util.*;

public class main {

    public static void opciok(){
        System.out.println("--- TESZTESETEK KIVALASZTASA ---");
        System.out.println("Mezok funkcioi");
        System.out.println("\t[00] Laborban uj genetikai kod letapogatasa");
        System.out.println("\t[01] Laborban mar letapogatott genetikai kod letapogatasa");
        System.out.println("\t[200] Ovohelyen Kopeny felvetele");
        System.out.println("\t[201] Ovohelyen Zsak felvetele");
        System.out.println("\t[202] Ovohelyen Kesztyu felvetele");
        System.out.println("\t[203] Ures Ovohelyen Vedofelszereles felvetele");
        System.out.println("\t[204] Szabad Teruleten Vedofelszereles felvetele");
        System.out.println("\t[300] Raktarban anyag felvetele");
        System.out.println("\t[301] Ures Raktarban anyag felvetele");
        System.out.println("\t[302] Anyag Felvetele De A Jatekos Tele Van");
        System.out.println("\t[303] Anyag Felvetele De A Jatekos Tele Van De Van Zsakja");
        System.out.println("\t[304] Anyag Felvetele De A Jatekos Tele Van De Van Zsakja Ami Teli Van");
        System.out.println("\t[305] Anyag Felvetele Szabad Mezorol");
        System.out.println("Agens kenese");
        System.out.println("\t[400] Tancolo Agens Kenese Vedtelen Virologusra");
        System.out.println("\t[401] Benito Agens Kenese Vedtelen Virologusra");
        System.out.println("\t[402] Felejto Agens Kenese Vedtelen Virologusra");
        System.out.println("\t[403] Vedo Agens Kenese Vedtelen Virologusra");
        System.out.println("\t[404] Agens kenese benult kopenyes kesztyus virologusra");
        System.out.println("\t[405] Agens kenese masra benultan");
        System.out.println("\t[406] Agens kenese kopenyes virologusra");
        System.out.println("\t[407] Agens kenese vedo agenses virologusra");
        System.out.println("\t[408] Agens kenese kopenyes kesztyus virologusra");
        System.out.println("\t[409] Agens kenese kesztyus virologusra kopennyel");
        System.out.println("\t[410] Agens kenese kesztyus virologusra sebezhetetlenseg agenssel");
        System.out.println("\t[500] Agens kenese magamra kopennyel");
        System.out.println("\t[501] Agens kenese magamra kesztyuvel");
        System.out.println("\t[502] Agens kenese magamra kopennyel es kesztyuvel");
        System.out.println("\t[503] Agens kenese magamra sebezhetetlenseg agenssel");
        System.out.println("\t[504] Benito agens kenese magamra");
        System.out.println("\t[505] Vitustanc agens kenese magamra");
        System.out.println("\t[506] Felejtes agens kenese magamra");
        System.out.println("\t[507] Sebezhetetlenseg agens kenese magamra");
        System.out.println("Mozgas - agensek hatasa alatt");
        System.out.println("\t[07] Vandorlas");
        System.out.println("\t[08] Nincs agens");
        System.out.println("\t[09] Vitustanccal");
        System.out.println("\t[10] Benulassal");
        System.out.println("\t[1001] Nem szomszedra");
        System.out.println("Lopas");
        System.out.println("\t[101] Nincs agens senkin");
        System.out.println("\t[102] Lopo benult");
        System.out.println("\t[103] Lopott benult");
        System.out.println("\t[104] Lehet lopni & Lopottnal nincs adott felszereles");
        System.out.println("\t[105] Lehet lopni & Lopottnal van adott felszereles");
        System.out.println("\t[106] Anyag Lopasa");
        System.out.println("Agens keszitese");
        System.out.println("\t[16] Benulas");
        System.out.println("\t[17] Vitustanc");
        System.out.println("\t[18] Sebezhetetlenseg");
        System.out.println("\t[19] Felejtes");
        System.out.println("\t[20] Nincs eleg anyaga hozza");
        System.out.println("Kor vege");
        System.out.println("\t[21] Felejteses tesztek");
        System.out.println("Kesztyuteszt egy agenssel");
        System.out.println("\t[22] Senkin nincs kesztyu");  // todo
        System.out.println("\t[23] Rakenten van kesztyu");  // todo
        System.out.println("\t[24] Rakenten es kenon van kesztyu"); // todo
        System.out.println("Zsakteszt");
        System.out.println("\t[25] Befer-e tobb anyag a zsakba?");
        System.out.println("\t[26] Felszereles eldobasa");
        System.out.println("\t[27] Agens oregedese");
    }

    public static void tesztFuttatasa(int index) throws CloneNotSupportedException {

        var skeleton= new Skeleton();

        switch (index){
            //Mezokkel kapcsolatos dolgok
            case 0: skeleton.MezokFunkcioiUjGenKodTapogatas();   break;
            case 1: skeleton.MezokFunkcioiMarTanultGenKodTapogatas();   break;
            //Felszerelesek felvetele
            case 200: skeleton.FelszerelesFelveteleOvohelyrol("-- Felszerelesfelvetel Kopeny TESZT --", new Kopeny());   break;
            case 201: skeleton.FelszerelesFelveteleOvohelyrol("-- Felszerelesfelvetel Zsak TESZT --", new Zsak());   break;
            case 202: skeleton.FelszerelesFelveteleOvohelyrol("-- Felszerelesfelvetel Kesztyu TESZT --", new Kopeny());   break;
            case 203: skeleton.FelszerelesFelveteleUresOvohelyrol();   break;
            case 204: skeleton.FelszerelesFelveteleSzabadMezorol();   break;
            case 205: skeleton.FelszerelesFelveteleTeleVan();   break;
            //Anyagok felvetele
            case 300: skeleton.AnyagFelvetele();   break;
            case 301: skeleton.AnyagFelveteleUresRaktarbol(); break;
            case 302: skeleton.AnyagFelveteleVanAnyagJatekosTelevan(); break;
            case 303: skeleton.AnyagFelveteleVanAnyagJatekosTelevanDeVanZsakja(); break;
            case 304: skeleton.AnyagFelveteleVanAnyagJatekosTelevanDeVanZsakjaAmiTelevan(); break;
            case 305: skeleton.AnyagFelveteleSzabadMezorol();   break;
            //Agens kenese
            case 400: skeleton.AgenskenesTeszt("-- Tancolo Agens Kenese Vedtelen Virologusra TESZT --", new Vitustanc(3), new ArrayList<>(), new ArrayList<>());  break;
            case 401: skeleton.AgenskenesTeszt("-- Benito Agens Kenese Vedtelen Virologusra TESZT --", new Benulas(3), new ArrayList<>(), new ArrayList<>());    break;
            case 402: skeleton.AgenskenesTeszt("-- Felejto Agens Kenese Vedtelen Virologusra TESZT --", new Felejtes(3), new ArrayList<>(), new ArrayList<>());   break;
            case 403: skeleton.AgenskenesTeszt("-- Vedo Agens Kenese Vedtelen Virologusra TESZT --", new Sebezhetetlenseg(3), new ArrayList<>(), new ArrayList<>());   break;
            case 404: {
                ArrayList<TulajdonsagModosito> kenettTMi = new ArrayList<TulajdonsagModosito>();
                kenettTMi.add(new Benulas(3));
                kenettTMi.add(new Kesztyu());
                kenettTMi.add(new Kopeny());
                skeleton.AgenskenesTeszt("-- Agens kenese benult kopenyes kesztyus Virologusra TESZT --", new Vitustanc(3), new ArrayList<>(), kenettTMi);
                break;
            }
            case 405: {
                ArrayList<TulajdonsagModosito> kenoTMi = new ArrayList<TulajdonsagModosito>();
                kenoTMi.add(new Benulas(3));
                skeleton.AgenskenesTeszt("-- Agens kenese masra benultan TESZT --", new Vitustanc(3), kenoTMi, new ArrayList<>());
                break;
            }
            case 406: {
                ArrayList<TulajdonsagModosito> kenettTMi = new ArrayList<TulajdonsagModosito>();
                kenettTMi.add(new Kopeny());
                skeleton.AgenskenesTeszt("-- Agens kenese kopenyes Virologusra TESZT --", new Vitustanc(3), new ArrayList<>(), kenettTMi);
                break;
            }
            case 407: {
                ArrayList<TulajdonsagModosito> kenettTMi = new ArrayList<TulajdonsagModosito>();
                kenettTMi.add(new Sebezhetetlenseg(3));
                skeleton.AgenskenesTeszt("-- Agens kenese vedo agenses virologusra TESZT --", new Vitustanc(3), new ArrayList<>(), kenettTMi);
                break;
            }
            case 408: {
                ArrayList<TulajdonsagModosito> kenettTMi = new ArrayList<TulajdonsagModosito>();
                kenettTMi.add(new Kesztyu());
                kenettTMi.add(new Kopeny());
                skeleton.AgenskenesTeszt("-- Agens kenese kopenyes kesztyus virologusra TESZT --", new Vitustanc(3), new ArrayList<>(), kenettTMi);
                break;
            }
            case 409: {
                ArrayList<TulajdonsagModosito> kenettTMi = new ArrayList<TulajdonsagModosito>();
                kenettTMi.add(new Kesztyu());
                ArrayList<TulajdonsagModosito> kenoTMi = new ArrayList<TulajdonsagModosito>();
                kenoTMi.add(new Kopeny());
                skeleton.AgenskenesTeszt("-- Agens kenese kesztyus virologusra kopennyel TESZT --", new Vitustanc(3), kenoTMi, kenettTMi);
                break;
            }
            case 410: {
                ArrayList<TulajdonsagModosito> kenettTMi = new ArrayList<TulajdonsagModosito>();
                kenettTMi.add(new Kesztyu());
                ArrayList<TulajdonsagModosito> kenoTMi = new ArrayList<TulajdonsagModosito>();
                kenoTMi.add(new Sebezhetetlenseg(3));
                skeleton.AgenskenesTeszt("-- Agens kenese kesztyus virologusra sebezhetetlenseg agenssel TESZT --", new Vitustanc(3), kenoTMi, kenettTMi);
                break;
            }
            case 500: {
                ArrayList<TulajdonsagModosito> viroTMi = new ArrayList<TulajdonsagModosito>();
                viroTMi.add(new Kopeny());
                skeleton.AgenskenesMagamraTeszt("-- Agens kenese magamra kopennyel TESZT --", new Vitustanc(3), viroTMi);
                break;
            }
            case 501: {
                ArrayList<TulajdonsagModosito> viroTMi = new ArrayList<TulajdonsagModosito>();
                viroTMi.add(new Kesztyu());
                skeleton.AgenskenesMagamraTeszt("-- Agens kenese magamra kesztyuvel TESZT --", new Vitustanc(3), viroTMi);
                break;
            }
            case 502: {
                ArrayList<TulajdonsagModosito> viroTMi = new ArrayList<TulajdonsagModosito>();
                viroTMi.add(new Kopeny());
                viroTMi.add(new Kesztyu());
                skeleton.AgenskenesMagamraTeszt("-- Agens kenese magamra kopennyel es kesztyuvel TESZT --", new Vitustanc(3), viroTMi);
                break;
            }
            case 503: {
                ArrayList<TulajdonsagModosito> viroTMi = new ArrayList<TulajdonsagModosito>();
                viroTMi.add(new Sebezhetetlenseg(3));
                skeleton.AgenskenesMagamraTeszt("-- Agens kenese magamra sebezhetetlenseg agenssel TESZT --", new Vitustanc(3), viroTMi);
                break;
            }
            case 504: {
                skeleton.AgenskenesMagamraTeszt("-- Benito agens kenese magamra TESZT --", new Benulas(3), new ArrayList<>());
                break;
            }
            case 505: {
                skeleton.AgenskenesMagamraTeszt("-- Vitustanc agens kenese magamra TESZT --", new Vitustanc(3), new ArrayList<>());
                break;
            }
            case 506: {
                skeleton.AgenskenesMagamraTeszt("-- Felejtes agens kenese magamra TESZT --", new Felejtes(3), new ArrayList<>());
                break;
            }
            case 507: {
                skeleton.AgenskenesMagamraTeszt("-- Sebezhetetlenseg agens kenese magamra TESZT --", new Sebezhetetlenseg(3), new ArrayList<>());
                break;
            }

            //mozgas
            case 7: skeleton.MezokFunkcioiVandorlas();   break;
            case 8: skeleton.agensNelkul();  break;
            case 9: skeleton.vitustanccal(); break;
            case 10: skeleton.benulassal();  break;
            case 1001: skeleton.nemSzomszedra();  break;
            //lopas
            case 101: skeleton.lopasAgensNelkul(); break;
            case 102: skeleton.lopoBenult(); break;
            case 103: skeleton.meglopottBenult(); break;
            case 104: skeleton.lopottFelszerelesNemAllRendelkezesre(); break;
            case 105: skeleton.sikeresLopasZsakkal(); break;
            case 106: skeleton.AnyagLopasa(); break;
            //agenskeszites
            case 16: skeleton.BenitoAgensKeszitese(); break;
            case 17: skeleton.VitustancAgensKeszitese(); break;
            case 18: skeleton.SebezhetetlensegAgensKeszitese(); break;
            case 19: skeleton.FelejtesAgensKeszitese(); break;
            case 20: skeleton.AgensKesziteseNincsAnyag(); break; // !!!!
            //felejtes
            case 21: skeleton.felejtesTesztelese(); break;
            // Kesztyuesztek
            case 22: skeleton.senkinelNincsKesztyu(); break;
            case 23: skeleton.rakentenVanKesztyu(); break;
            case 24: skeleton.mindkettonVanKesztyu(); break;
            //zsakteszt
            case 25: skeleton.zsakTeszt(); break;
            // egyebek (meg nem kategorizaltak...
            case 26: skeleton.FelszerelesEldobasa(); break;
            case 27: skeleton.agensOregedese(); break;

        }
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        // Csodáltos menu a tesztesetek kivalasztasahoz :)
        Scanner in = new Scanner(System.in);
        int vMenu;

        do{
            // tesztek mutatasa
            opciok();

            // Valasztas
            try{
                vMenu = in.nextInt();
                tesztFuttatasa(vMenu);
            } catch (Exception e){
                System.out.println("Hiba történt, teszteset megszakítása...");
            }

            System.out.println("Tovabblepeshez nyomj egy entert!");
            //elso sorveg
            in.nextLine();
            //varakozas az enterre
            in.nextLine();
        } while(true);
    }
}

import Logika.Virologus;
import Modell.Agensek.*;
import Modell.Anyagok.Aminosav;
import Modell.Anyagok.Anyag;
import Modell.Anyagok.AnyagTarolo;
import Modell.Anyagok.Nukleotid;
import Modell.Genetika.GenetikaiKod;
import Modell.Palya.Labor;
import Modell.Palya.Ovohely;
import Modell.Palya.Raktar;
import Modell.Palya.TeruletiElem;
import Modell.TulajdonsagModosito;
import Modell.Vedofelszereles.Kesztyu;
import Modell.Vedofelszereles.Kopeny;
import Modell.Vedofelszereles.Vedofelszereles;
import Modell.Vedofelszereles.Zsak;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Skeleton {

    public void AnyagLopasa(){
        System.out.println("Virologus a, es b letrehozasa...");
        Virologus v1 = new Virologus();
        v1.setNev("a");
        Virologus v2 = new Virologus();
        v2.setNev("b");

        // v2-nek anyag adasa
        v2.anyagTarolasa(new Aminosav(69)); // ;)

        System.out.println("Benulas letrehozasa, es 'b'-re kenese...");
        v2.getAktivModositok().add(new Benulas(20));

        System.out.println("a anyagai: ");
        System.out.println(v1.getAnyagok().toString());

        System.out.println("b anyagai: ");
        System.out.println(v2.getAnyagok().toString());

        System.out.println("a-t meglopja b");
        v1.lopas(v2, null);

        System.out.println("Lopas sikeressegenek ellenorzese...");

        System.out.println("a anyagai: ");
        System.out.println(v1.getAnyagok().toString());

        System.out.println("b anyagai: ");
        System.out.println(v2.getAnyagok().toString());



        // System.out.println(v2.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt b szempontjabol." : "A lopas sikeres volt b szempontjabol.");
        // System.out.println(!v1.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt a szempontjabol." : "A lopas sikeres volt a szempontjabol.");
    }

    public void AnyagFelveteleVanAnyagJatekosTelevanDeVanZsakjaAmiTelevan(){
        Virologus v = new Virologus();
        v.setNev("Alice");

        // zsak adasa neki ami ures
        Zsak zs = new Zsak();
        v.vedofelszerelesTarolasa(zs);
        System.out.println("Maradek: " + v.anyagTarolasa(new Nukleotid(300)));    // A zsakjat is megtoltjuk

        Raktar r = new Raktar();
        r.anyagElhelyezese(new Nukleotid(40));

        v.setStartTerulet(r);

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.getAnyagok().toString());

        System.out.println(v.getNev() + " anyagot vesz fel tarolobol");
        v.anyagFelvetele(new Nukleotid(10));

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.anyagFelhasznalasa(new Nukleotid(110)).toString());
    }

    public void AnyagFelveteleVanAnyagJatekosTelevanDeVanZsakja(){
        Virologus v = new Virologus();
        v.setNev("Alice");
        v.anyagTarolasa(new Nukleotid(100));    // Virologus megtomese thiccccc

        // zsak adasa neki ami ures
        Zsak zs = new Zsak();
        v.vedofelszerelesTarolasa(zs);

        Raktar r = new Raktar();
        r.anyagElhelyezese(new Nukleotid(40));

        v.setStartTerulet(r);

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.getAnyagok().toString());

        System.out.println(v.getNev() + " anyagot vesz fel tarolobol (10 Nukleotidot)");
        v.anyagFelvetele(new Nukleotid(10));

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.anyagFelhasznalasa(new Nukleotid(110)).toString());

    }

    public void AnyagFelveteleVanAnyagJatekosTelevan(){
        Virologus v = new Virologus();
        v.setNev("Alice");
        v.anyagTarolasa(new Nukleotid(100));    // Virologus megtomese thiccccc

        Raktar r = new Raktar();
        r.anyagElhelyezese(new Nukleotid(40));

        v.setStartTerulet(r);

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.getAnyagok().toString());

        System.out.println(v.getNev() + " anyagot vesz fel tarolobol");
        v.anyagFelvetele(new Nukleotid(10));

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.getAnyagok().toString());
    }

    public void AnyagFelveteleUresRaktarbol(){
        Virologus v = new Virologus();
        v.setNev("Alice");

        Raktar r = new Raktar();

        v.setStartTerulet(r);

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.getAnyagok().Hasznalat(new Nukleotid(100)).getMennyiseg());

        System.out.println(v.getNev() + " anyagot vesz fel tarolobol");
        v.anyagFelvetele(new Nukleotid(10));

        System.out.println(v.getNev() + " anyagai:");
        System.out.println(v.getAnyagok().Hasznalat(new Nukleotid(100)).getMennyiseg());
    }

    // [26]
    public void FelszerelesEldobasa(){
        Virologus v = new Virologus();
        v.setNev("Alice");

        Kopeny k = new Kopeny();

        v.vedofelszerelesTarolasa(k);

        System.out.println(v.getNev() + " felszerelesei:");
        for(var a : v.getAktivVedofelszerelesek()){
            System.out.println(a.getClass());
        }

        System.out.println(v.getNev() + " eldobja a felszerelest...");
        v.vedofelszerelesEldobasa(k);

        System.out.println(v.getNev() + " felszerelesei:");
        for(var a : v.getAktivVedofelszerelesek()){
            System.out.println(a.getClass());
        }
    }

    // [200], [201], [202]
    public void FelszerelesFelveteleOvohelyrol(String title, Vedofelszereles felszereles){
        System.out.println(title);

        Ovohely o1 = new Ovohely();

        Vedofelszereles f1 = felszereles;

        System.out.println(f1.getClass() + " elhelyezese a(z) " + o1.getClass() + " teruletre...");
        o1.vedofelszerelesElhelyezese(f1);

        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        v1.setStartTerulet(o1);

        System.out.println(v1.getNev() + " fel szeretne venni a " + f1.getClass() + " felszerelest a(z) " + o1.getClass() + " teruletrol");
        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t" + v.getClass());
        }

        System.out.println(v1.getNev() + " felvesz egy " + f1.getClass() + "-t az ovohelyrol...");
        v1.vedofelszerelesFelvetele(f1);

        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getAktivVedofelszerelesek()){
            System.out.println("\t [AKTIVAK] " + v.getClass());
        }
        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t [TAROLTAK] " + v.getClass());
        }
    }

    // [203]
    public void FelszerelesFelveteleUresOvohelyrol(){
        System.out.println("-- Felszereles Felvetele Ures Ovohelyrol --");

        Ovohely o1 = new Ovohely();

        Vedofelszereles f1 = new Kopeny();

        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        v1.setStartTerulet(o1);

        System.out.println(v1.getNev() + " felszeretne venni a " + f1.getClass() + " felszereleset a(z) " + o1.getClass() + " teruletrol");
        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t" + v.getClass());
        }

        System.out.println(v1.getNev() + " megprobal felvenni egy " + f1.getClass() + "-t az ovohelyrol, de az ovohely ures.");
        v1.vedofelszerelesFelvetele(f1);

        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getAktivVedofelszerelesek()){
            System.out.println("\t [AKTIVAK] " + v.getClass());
        }
        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t [TAROLTAK] " + v.getClass());
        }
    }

    // [204]
    public void FelszerelesFelveteleSzabadMezorol() {
        System.out.println("-- Felszereles Felvetele Szabad Teruletrol --");

        TeruletiElem mezo = new TeruletiElem();

        Vedofelszereles f1 = new Kopeny();

        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        v1.setStartTerulet(mezo);

        System.out.println(v1.getNev() + " felszeretne venni a " + f1.getClass() + " felszereleset a(z) " + mezo.getClass() + " teruletrol");
        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t" + v.getClass());
        }

        System.out.println(v1.getNev() + " megprobal felvenni egy " + f1.getClass() + "-t egy szabad teruletrol.");
        v1.vedofelszerelesFelvetele(f1);

        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getAktivVedofelszerelesek()){
            System.out.println("\t [AKTIVAK] " + v.getClass());
        }
        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t [TAROLTAK] " + v.getClass());
        }
    }

    // [205]
    public void FelszerelesFelveteleTeleVan() {
        System.out.println("-- Felszereles Felvetele De A Virologus Tele Van --");

        Ovohely o1 = new Ovohely();

        Vedofelszereles f1 = new Zsak();

        System.out.println(f1.getClass() + " elhelyezese a(z) " + o1.getClass() + " teruletre...");
        o1.vedofelszerelesElhelyezese(f1);

        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        v1.setStartTerulet(o1);

        // Virologusnak 3 vedofelszereles adasa
        System.out.println(v1.getNev() + "-nek adunk 3 vedofelszerelest, hogy tele legyen.");
        v1.vedofelszerelesTarolasa(new Kopeny());
        v1.vedofelszerelesTarolasa(new Kesztyu());
        v1.vedofelszerelesTarolasa(new Zsak());

        System.out.println(v1.getNev() + " fel szeretne venni a " + f1.getClass() + " felszerelest a(z) " + o1.getClass() + " teruletrol");
        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t" + v.getClass());
        }

        System.out.println(v1.getNev() + " felvesz egy " + f1.getClass() + "-t az ovohelyrol...");
        v1.vedofelszerelesFelvetele(f1);

        System.out.println(v1.getNev() + " felszerelesei: ");

        for(Vedofelszereles v : v1.getAktivVedofelszerelesek()){
            System.out.println("\t [AKTIVAK] " + v.getClass());
        }
        for(Vedofelszereles v : v1.getHordozottVedofelszerelesek()){
            System.out.println("\t [TAROLTAK] " + v.getClass());
        }
    }

    // [400] - [410]
    public void AgenskenesTeszt(String title, Agens mit, ArrayList<TulajdonsagModosito> kenoTMi, ArrayList<TulajdonsagModosito> kenettTMi){
        System.out.println(title);

        // init v1
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        for(TulajdonsagModosito a : kenoTMi){
            v1.getAktivModositok().add(a);
        }

        // init v2
        Virologus v2 = new Virologus();
        v2.setNev("Bob");

        for(TulajdonsagModosito a : kenettTMi){
            v2.getAktivModositok().add(a);
        }

        // BEFORE
        System.out.println(v1.getNev() + " támadja " + v2.getNev() + "-t");

        System.out.println(v1.getNev() + " ráható ágensei:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható ágensei:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println("Ágens vetése...");
        v1.agensVetese(mit, v2);

        System.out.println(v1.getNev() + " megkente " + v2.getNev());

        System.out.println(v1.getNev() + " ráható ágensei:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható ágensei:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }
    }

    // [500] - [507]
    public void AgenskenesMagamraTeszt(String title, Agens mit, ArrayList<TulajdonsagModosito> viroTMi){
        System.out.println(title);

        // init v1
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        for(TulajdonsagModosito a : viroTMi){
            v1.getAktivModositok().add(a);
        }

        // BEFORE
        System.out.println(v1.getNev() + " támadja " + v1.getNev() + "-t");

        System.out.println(v1.getNev() + " ráható ágensei:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println("Ágens vetése...");
        v1.agensVetese(mit, v1);

        System.out.println(v1.getNev() + " megkente " + v1.getNev());

        System.out.println(v1.getNev() + " ráható ágensei:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }
    }

    // [07]
    public void MezokFunkcioiVandorlas(){
        System.out.println("-- Mezok Funkciok Vandorlas --");

        TeruletiElem t1 = new TeruletiElem();
        Labor t2 = new Labor();

        // szomszedsag kialakitasa
        t1.addSzomszed(t2);
        t2.addSzomszed(t1);

        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        // kezdo pozicioba helyezes
        v1.setStartTerulet(t1);

        System.out.println(v1.getNev() + " kezdopozicioja " + v1.getJelenlegiMezo().getClass());
        System.out.println(v1.getNev() + " hato agensek: ");

        for(var a : v1.getAktivModositok()){
            System.out.println(a.getClass());
        }

        System.out.println(v1.getNev() + " atlep a(z) " + t2.getClass() + " mezore...");
        v1.mozgas(t2);

        System.out.println(v1.getNev() + " pozicioja " + v1.getJelenlegiMezo().getClass());
        System.out.println(v1.getNev() + " hato agensek: ");

        for(var a : v1.getAktivModositok()){
            System.out.println(a.getClass());
        }
    }

    // [00]
    public void MezokFunkcioiUjGenKodTapogatas(){
        System.out.println("-- Mezok Funkciok Letapogatas --");

        Labor l1 = new Labor();
        l1.setGenKod(new GenetikaiKod(null, null));

        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        v1.setStartTerulet(l1);

        System.out.println(v1.getNev() + " genetikai kodjai:");
        for(var a : v1.getIsmertKodok()){
            System.out.println(a);
        }

        System.out.println(v1.getNev() + " a(z) " + l1.getClass() + "mezon tapogat le...");
        v1.kodLetapogatasa();

        System.out.println(v1.getNev() + " genetikai kodjai:");
        for(var a : v1.getIsmertKodok()){
            System.out.println(a);
        }
    }

    // [01]
    public void MezokFunkcioiMarTanultGenKodTapogatas(){
        System.out.println("-- Mezok Funkciok Letapogatas --");

        Labor l1 = new Labor();
        l1.setGenKod(new GenetikaiKod(null, null));

        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        v1.setStartTerulet(l1);

        System.out.println(v1.getNev() + " genetikai kodjai:");
        for(var a : v1.getIsmertKodok()){
            System.out.println(a);
        }

        System.out.println(v1.getNev() + " a(z) " + l1.getClass() + "mezon tapogat le...");
        v1.kodLetapogatasa();

        System.out.println(v1.getNev() + " genetikai kodjai:");
        for(var a : v1.getIsmertKodok()){
            System.out.println(a);
        }

        // Ujra tapogatja ugyan azt a kodot...
        System.out.println(v1.getNev() + " a(z) " + l1.getClass() + "mezon tapogat le ugyan azt a kodot...");
        v1.kodLetapogatasa();

        System.out.println(v1.getNev() + " genetikai kodjai:");
        for(var a : v1.getIsmertKodok()){
            System.out.println(a);
        }
    }

    // [16]
    public void BenitoAgensKeszitese() {
        System.out.println("-- Benito Agens Keszitese TESZT --");

        //Virologus elkeszitese
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        //Szukseges anyagok a genetikai kodhoz
        Aminosav szukseges_a = new Aminosav();
        szukseges_a.setMennyiseg(10);
        Nukleotid szukseges_n = new Nukleotid();
        szukseges_n.setMennyiseg(30);
        Set<Anyag> szukseges_anyagok = new HashSet<Anyag>();
        szukseges_anyagok.add(szukseges_a);
        szukseges_anyagok.add(szukseges_n);

        //Benulas agens letrehozasa
        Benulas benulas = new Benulas(-1);

        //Genetikai kod elkeszitese
        GenetikaiKod gk1 = new GenetikaiKod(szukseges_anyagok, benulas);

        System.out.println(v1.getNev() + " benulas agenst akar csinalni " + gk1.getClass().getName() + " genetikai kodbol.");

        //A virologusnak atadjuk a kodot.

        v1.getIsmertKodok().add(gk1);
        System.out.println(v1.getNev() + " genetikai kodjai: ");
        for (GenetikaiKod gk : v1.getIsmertKodok()) {
            System.out.println(gk.getClass().getName());
        }

        //Virologust feltoltjuk az anyagokkal
        Aminosav v1_a = new Aminosav();
        v1_a.setMennyiseg(15);
        Nukleotid v1_n = new Nukleotid();
        v1_n.setMennyiseg(40);
        AnyagTarolo tar = new AnyagTarolo();
        v1.anyagTarolasa(v1_a);
        v1.anyagTarolasa(v1_n);

        System.out.println("A virologus anyagai: " + v1_a + ", " + v1_n);

        //Letrehozzuk az agenst
        v1.agensKeszitese(gk1);

        System.out.println("A virologus agensei: " + v1.getFelhasznalhatoAgensek());
    }

    // [17]
    public void VitustancAgensKeszitese() {
        System.out.println("-- Vitustanc Agens Keszitese TESZT --");

        //Virologus elkeszitese
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        //Szukseges anyagok a genetikai kodhoz
        Aminosav szukseges_a = new Aminosav();
        szukseges_a.setMennyiseg(10);
        Nukleotid szukseges_n = new Nukleotid();
        szukseges_n.setMennyiseg(5);
        Set<Anyag> szukseges_anyagok = new HashSet<Anyag>();
        szukseges_anyagok.add(szukseges_a);
        szukseges_anyagok.add(szukseges_n);

        //Vitustanc agens letrehozasa
        Vitustanc vitustanc = new Vitustanc(-1);

        //Genetikai kod elkeszitese
        GenetikaiKod gk1 = new GenetikaiKod(szukseges_anyagok, vitustanc);

        System.out.println(v1.getNev() + " vitustanc agenst akar csinalni " + gk1.getClass().getName() + " genetikai kodbol.");

        //A virologusnak atadjuk a kodot.

        v1.getIsmertKodok().add(gk1);
        System.out.println(v1.getNev() + " genetikai kodjai: ");
        for (GenetikaiKod gk : v1.getIsmertKodok()) {
            System.out.println(gk.getClass().getName());
        }

        //Virologust feltoltjuk az anyagokkal
        Aminosav v1_a = new Aminosav();
        v1_a.setMennyiseg(15);
        Nukleotid v1_n = new Nukleotid();
        v1_n.setMennyiseg(10);
        AnyagTarolo tar = new AnyagTarolo();
        v1.anyagTarolasa(v1_a);
        v1.anyagTarolasa(v1_n);

        System.out.println("A virologus anyagai: " + v1_a + ", " + v1_n);

        //Letrehozzuk az agenst
        v1.agensKeszitese(gk1);

        System.out.println("A virologus agensei: " + v1.getFelhasznalhatoAgensek());
    }

    // [18]
    public void SebezhetetlensegAgensKeszitese() {
        System.out.println("-- Sebezhetetlenseg Agens Keszitese TESZT --");

        //Virologus elkeszitese
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        //Szukseges anyagok a genetikai kodhoz
        Aminosav szukseges_a = new Aminosav();
        szukseges_a.setMennyiseg(20);
        Nukleotid szukseges_n = new Nukleotid();
        szukseges_n.setMennyiseg(5);
        Set<Anyag> szukseges_anyagok = new HashSet<Anyag>();
        szukseges_anyagok.add(szukseges_a);
        szukseges_anyagok.add(szukseges_n);

        //Sebezhetetlenseg agens letrehozasa
        Sebezhetetlenseg sebezhetetlenseg = new Sebezhetetlenseg(-1);

        //Genetikai kod elkeszitese
        GenetikaiKod gk1 = new GenetikaiKod(szukseges_anyagok, sebezhetetlenseg);

        System.out.println(v1.getNev() + " sebezhetetlenseg agenst akar csinalni " + gk1.getClass().getName() + " genetikai kodbol.");

        //A virologusnak atadjuk a kodot.

        v1.getIsmertKodok().add(gk1);
        System.out.println(v1.getNev() + " genetikai kodjai: ");
        for (GenetikaiKod gk : v1.getIsmertKodok()) {
            System.out.println(gk.getClass().getName());
        }

        //Virologust feltoltjuk az anyagokkal
        Aminosav v1_a = new Aminosav();
        v1_a.setMennyiseg(20);
        Nukleotid v1_n = new Nukleotid();
        v1_n.setMennyiseg(10);
        AnyagTarolo tar = new AnyagTarolo();
        v1.anyagTarolasa(v1_a);
        v1.anyagTarolasa(v1_n);

        System.out.println("A virologus anyagai: " + v1_a + ", " + v1_n);

        //Letrehozzuk az agenst
        v1.agensKeszitese(gk1);

        System.out.println("A virologus agensei: " + v1.getFelhasznalhatoAgensek());
    }

    // [19]
    public void FelejtesAgensKeszitese() {
        System.out.println("-- Felejtes Agens Keszitese TESZT --");

        //Virologus elkeszitese
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        //Szukseges anyagok a genetikai kodhoz
        Aminosav szukseges_a = new Aminosav();
        szukseges_a.setMennyiseg(40);
        Nukleotid szukseges_n = new Nukleotid();
        szukseges_n.setMennyiseg(40);
        Set<Anyag> szukseges_anyagok = new HashSet<Anyag>();
        szukseges_anyagok.add(szukseges_a);
        szukseges_anyagok.add(szukseges_n);

        //Felejtes agens letrehozasa
        Felejtes felejtes = new Felejtes(-1);

        //Genetikai kod elkeszitese
        GenetikaiKod gk1 = new GenetikaiKod(szukseges_anyagok, felejtes);

        System.out.println(v1.getNev() + " felejtes agenst akar csinalni " + gk1.getClass().getName() + " genetikai kodbol.");

        //A virologusnak atadjuk a kodot.

        v1.getIsmertKodok().add(gk1);
        System.out.println(v1.getNev() + " genetikai kodjai: ");
        for (GenetikaiKod gk : v1.getIsmertKodok()) {
            System.out.println(gk.getClass().getName());
        }

        //Virologust feltoltjuk az anyagokkal
        Aminosav v1_a = new Aminosav();
        v1_a.setMennyiseg(50);
        Nukleotid v1_n = new Nukleotid();
        v1_n.setMennyiseg(50);
        AnyagTarolo tar = new AnyagTarolo();
        v1.anyagTarolasa(v1_a);
        v1.anyagTarolasa(v1_n);

        System.out.println("A virologus anyagai: " + v1_a + ", " + v1_n);

        //Letrehozzuk az agenst
        v1.agensKeszitese(gk1);

        System.out.println("A virologus agensei: " + v1.getFelhasznalhatoAgensek());
    }

    // [20]
    public void AgensKesziteseNincsAnyag() {
        //Virologus elkeszitese
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        //Szukseges anyagok a genetikai kodhoz
        Aminosav szukseges_a = new Aminosav();
        szukseges_a.setMennyiseg(40);
        Nukleotid szukseges_n = new Nukleotid();
        szukseges_n.setMennyiseg(40);
        Set<Anyag> szukseges_anyagok = new HashSet<Anyag>();
        szukseges_anyagok.add(szukseges_a);
        szukseges_anyagok.add(szukseges_n);

        //Felejtes agens letrehozasa
        Felejtes felejtes = new Felejtes(-1);

        //Genetikai kod elkeszitese
        GenetikaiKod gk1 = new GenetikaiKod(szukseges_anyagok, felejtes);

        System.out.println(v1.getNev() + " felejtes agenst akar csinalni " + gk1.getClass().getName() + " genetikai kodbol.");

        //A virologusnak atadjuk a kodot.

        v1.getIsmertKodok().add(gk1);
        System.out.println(v1.getNev() + " genetikai kodjai: ");
        for (GenetikaiKod gk : v1.getIsmertKodok()) {
            System.out.println(gk.getClass().getName());
        }

        //Virologust feltoltjuk az anyagokkal
        Aminosav v1_a = new Aminosav();
        v1_a.setMennyiseg(10);
        Nukleotid v1_n = new Nukleotid();
        v1_n.setMennyiseg(50);
        AnyagTarolo tar = new AnyagTarolo();
        v1.anyagTarolasa(v1_a);
        v1.anyagTarolasa(v1_n);

        System.out.println("A virologus anyagai: " + v1_a + ", " + v1_n);

        //Letrehozzuk az agenst
        v1.agensKeszitese(gk1);

        System.out.println("A virologus agensei: " + v1.getFelhasznalhatoAgensek());
    }

    // [03]
    public void AnyagFelvetele(){

        // Virologus elkeszitese
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        // Raktar anyaggal egyutt elkeszitese
        Nukleotid n1 = new Nukleotid();
        n1.setMennyiseg(73);
        Raktar r1 = new Raktar();
        r1.anyagElhelyezese(n1);
        v1.setStartTerulet(r1);

        // Anyag amit akar felvenni, felvetele
        Nukleotid akarom = new Nukleotid();
        akarom.setMennyiseg(32);

        System.out.println(v1.getNev() + " akar felvenni " + n1.getMennyiseg() + " Nukleotid anyagot " + r1.getClass() + "-rol");
        System.out.print(v1.getNev() + " anyagai:");
        System.out.println(v1.getAnyagok().toString());


        System.out.println(v1.getNev() + " felveszi az anyagot a tarolobol...");
        // Anyag felvetele
        v1.anyagFelvetele(akarom);

        System.out.print(v1.getNev() + " anyagai:");
        System.out.println(v1.getAnyagok().toString());
    }

    public void AnyagFelveteleSzabadMezorol(){

        // Virologus elkeszitese
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        // Raktar anyaggal egyutt elkeszitese
        Nukleotid n1 = new Nukleotid();
        n1.setMennyiseg(73);
        TeruletiElem r1 = new TeruletiElem();
        v1.setStartTerulet(r1);

        // Anyag amit akar felvenni, felvetele
        Nukleotid akarom = new Nukleotid();
        akarom.setMennyiseg(32);

        System.out.println(v1.getNev() + " akar felvenni " + n1.getMennyiseg() + " Nukleotid anyagot " + r1.getClass() + "-rol");
        System.out.print(v1.getNev() + " anyagai:");
        System.out.println(v1.getAnyagok().toString());


        System.out.println(v1.getNev() + " felveszi az anyagot a tarolobol...");
        // Anyag felvetele
        v1.anyagFelvetele(akarom);

        System.out.print(v1.getNev() + " anyagai:");
        System.out.println(v1.getAnyagok().toString());
    }
    //region felejtes
    // [21]
    public void felejtesTesztelese(){
        //Virologus elkeszitese
        System.out.println("Virologus letrehozasa");
        Virologus v1 = new Virologus();

        System.out.println("Random genetikai kod megismerese");
        GenetikaiKod ranGenKod = new GenetikaiKod(null, null);
        v1.getIsmertKodok().add(ranGenKod);

        System.out.println("Ennyi kód ismert felejtés előtt: "+  v1.getIsmertKodok().size());
        System.out.println("Felejtes agens hozzaadasa");
        v1.getAktivModositok().add(new Felejtes(3));
        System.out.println("Kor lepese, a felejtes ekkor tortenik...");
        v1.onTickReceived(42);
        System.out.println("Ennyi kód ismert felejtés után: "+  v1.getIsmertKodok().size());
    }

    //endregion
    //region mozgas_agensekkel
    public static Virologus createAliceAndThreeFields(){
        // Virologus elkeszitese
        System.out.println("Virologus keszult!");
        Virologus v1 = new Virologus();
        v1.setNev("Alice");

        System.out.println("Raktar keszult!");
        Raktar t1 = new Raktar();
        System.out.println("Ovohely keszult!");
        Ovohely o1 = new Ovohely();

        System.out.println("Labor keszult!");
        Labor l1 = new Labor();
        l1.addSzomszed(t1);
        l1.addSzomszed(o1);

        v1.setStartTerulet(l1);

        return v1;
    }

    // [08]
    public void agensNelkul(){
        var v1 = createAliceAndThreeFields();
        //A raktar szomszed megkeresese
        Raktar cel = (Raktar) v1.getJelenlegiMezo().getSzomszedok().stream().filter(p-> p instanceof Raktar).findFirst().get();
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");
        System.out.println("Mozgas a raktarba....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");
    }

    // [10]
    public void benulassal(){
        var v1 = createAliceAndThreeFields();
        Raktar cel = (Raktar) v1.getJelenlegiMezo().getSzomszedok().stream().filter(p-> p instanceof Raktar).findFirst().get();
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");

        System.out.println("Benulas keszitese, es virologushoz adasa...");
        v1.getAktivModositok().add(new Benulas(3));

        System.out.println("Jelenlegi mezo mentese...");
        var mezo = v1.getJelenlegiMezo();
        System.out.println("Mozgasi kiserlet benultan a raktarba....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() == mezo ? "azonos" : "nem azonos") + " az elozovel.");
    }

    // [101]
    public void nemSzomszedra(){
        var v1 = createAliceAndThreeFields();
        System.out.println("Nem szomszedos cel (ures teruleti elem) letrehozasa...");
        TeruletiElem cel = new TeruletiElem();
        System.out.println("Jelenlegi mezo mentese...");
        var mezo = v1.getJelenlegiMezo();
        System.out.println("Mozgasi kiserlet nem szomszedos mezore....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() == mezo ? "azonos" : "nem azonos") + " az elozovel.");
    }

    // [09]
    public void vitustanccal(){
        var v1 = createAliceAndThreeFields();
        Raktar cel = (Raktar) v1.getJelenlegiMezo().getSzomszedok().stream().filter(p-> p instanceof Raktar).findFirst().get();
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");

        System.out.println("Vitustanc keszitese, es virologushoz adasa...");
        v1.getAktivModositok().add(new Vitustanc(3));

        System.out.println("Jelenlegi mezo mentese...");
        var mezo = v1.getJelenlegiMezo();

        System.out.println("Mozgas vitustanccal a raktarba #1....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");

        System.out.println("Jelenlegi mezo visszaalitasa...");
        v1.setStartTerulet(mezo);

        System.out.println("Mozgas vitustanccal a raktarba #2....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");

        System.out.println("Jelenlegi mezo visszaalitasa...");
        v1.setStartTerulet(mezo);

        System.out.println("Mozgas vitustanccal a raktarba #3....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");

        System.out.println("Jelenlegi mezo visszaalitasa...");
        v1.setStartTerulet(mezo);

        System.out.println("Mozgas vitustanccal a raktarba #4....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");
    }

    // [22]
    public void senkinelNincsKesztyu(){
        // init
        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        Virologus v2 = new Virologus();
        v2.setNev("Bob");
        Felejtes f1 = new Felejtes();

        System.out.println(v1.getNev() + " támadja " + v2.getNev());

        System.out.println(v1.getNev() + " ráható ágensei:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható ágensei:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println("Ágens vetése...");
        v1.agensVetese(f1, v2);

        System.out.println(v1.getNev() + " megkente " + v2.getNev());

        System.out.println(v1.getNev() + " ráható ágensei:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható ágensei:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }
    }

    // [23]
    public void rakentenVanKesztyu(){
        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        Virologus v2 = new Virologus();
        v2.setNev("Bob");
        Felejtes f1 = new Felejtes();
        v2.vedofelszerelesTarolasa(new Kesztyu());

        System.out.println(v1.getNev() + " támadja " + v2.getNev());

        System.out.println(v1.getNev() + " ráható módosítói:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható módosítói:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println("Ágens vetése...");
        v1.agensVetese(f1, v2);

        System.out.println(v1.getNev() + " megkente " + v2.getNev());

        System.out.println(v1.getNev() + " ráható módosítói:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható módosítói:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }
    }

    // [24]
    public void mindkettonVanKesztyu(){
        Virologus v1 = new Virologus();
        v1.setNev("Alice");
        Virologus v2 = new Virologus();
        v2.setNev("Bob");
        Felejtes f1 = new Felejtes();
        v1.vedofelszerelesTarolasa(new Kesztyu());
        v2.vedofelszerelesTarolasa(new Kesztyu());

        System.out.println(v1.getNev() + " támadja " + v2.getNev());

        System.out.println(v1.getNev() + " ráható módosítói:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható módosítói:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println("Ágens vetése...");
        v1.agensVetese(f1, v2);

        System.out.println(v1.getNev() + " megkente " + v2.getNev());

        System.out.println(v1.getNev() + " ráható módosítói:");
        for(var a : v1.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }

        System.out.println(v2.getNev() + " ráható módosítói:");
        for(var a : v2.getAktivModositok()){
            System.out.println("\t"+a.getClass());
        }
    }
    //endregion
    //region zsak
    // [25]
    public void zsakTeszt() throws CloneNotSupportedException {

        System.out.println("Virologus letrehozasa");
        var v1 = new Virologus();
        System.out.println("AlapTarolo maximumra toltese");
        v1.anyagTarolasa(new Aminosav(100));
        System.out.println("Zsak keszitesse, es hozzaadasa");
        v1.getAktivModositok().add(new Zsak());
        //
        var res = v1.anyagTarolasa(new Aminosav(15));
        System.out.println(res == null ? "A tarolas sikeres volt." : "A tarolas sikertelen volt.");

        System.out.println("Anyag felhasznalasa, a zsak tartalmat is igenylo mennyisegig");
        var hasznalatiIgeny = new Aminosav(110);
        var anyag = v1.anyagFelhasznalasa(hasznalatiIgeny);
        System.out.println("A sikeresen használt anyag menyisége: " + anyag.getMennyiseg() );
    }

    //endregion
    //region lopas
    // [11]
    public void lopasAgensNelkul(){
        System.out.println("Virologus a, es b letrehozasa...");
        Virologus v1 = new Virologus();
        v1.setNev("a");
        Virologus v2 = new Virologus();
        v2.setNev("b");
        System.out.println("Lopando felszereles letrehozasa, tarolasa 'b' altal...");
        var lopando = new Kopeny();
        v2.getAktivVedofelszerelesek().add(lopando);
        System.out.println("a-t meglopja b");
        v1.lopas(v2, lopando);
        System.out.println("Lopas sikertelensegenek ellenorzese...");
        System.out.println(v2.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt b szempontjabol." : "A lopas sikeres volt b szempontjabol.");
        System.out.println(!v1.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt a szempontjabol." : "A lopas sikeres volt a szempontjabol.");
    }

    // [12]
    public void lopoBenult() {
        System.out.println("Virologus a, es b letrehozasa...");

        Virologus v1 = new Virologus();
        v1.setNev("a");
        Virologus v2 = new Virologus();
        v2.setNev("b");
        System.out.println("Lopando felszereles letrehozasa, tarolasa 'b' altal...");
        var lopando = new Kopeny();
        System.out.println("Benulas letrehozasa, es 'a'-ra kenese...");
        v1.getAktivModositok().add(new Benulas(20));
        v2.getAktivVedofelszerelesek().add(lopando);
        System.out.println("a-t meglopja b");
        v1.lopas(v2, lopando);
        System.out.println("Lopas sikertelensegenek ellenorzese...");
        System.out.println(v2.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt b szempontjabol." : "A lopas sikeres volt b szempontjabol.");
        System.out.println(!v1.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt a szempontjabol." : "A lopas sikeres volt a szempontjabol.");
    }

    // [13]
    public void  meglopottBenult(){
        System.out.println("Virologus a, es b letrehozasa...");
        Virologus v1 = new Virologus();
        v1.setNev("a");
        Virologus v2 = new Virologus();
        v2.setNev("b");
        System.out.println("Lopando felszereles letrehozasa, tarolasa 'b' altal...");
        var lopando = new Kopeny();
        System.out.println("Benulas letrehozasa, es 'b'-re kenese...");
        v2.getAktivModositok().add(new Benulas(20));
        v2.getAktivVedofelszerelesek().add(lopando);
        System.out.println("a-t meglopja b");
        v1.lopas(v2, lopando);
        System.out.println("Lopas sikeressegenek ellenorzese...");
        System.out.println(v2.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt b szempontjabol." : "A lopas sikeres volt b szempontjabol.");
        System.out.println(!v1.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt a szempontjabol." : "A lopas sikeres volt a szempontjabol.");
    }

    // [14]
    public void lopottFelszerelesNemAllRendelkezesre() {
        System.out.println("Virologus a, es b letrehozasa...");
        Virologus v1 = new Virologus();
        v1.setNev("a");
        Virologus v2 = new Virologus();
        v2.setNev("b");
        System.out.println("Lopando felszereles letrehozasa, tarolasa 'b' altal...");
        var lopando = new Kopeny();
        System.out.println("Benulas letrehozasa, es 'b'-re kenese...");
        v2.getAktivModositok().add(new Benulas(20));
        v2.getAktivVedofelszerelesek().add(lopando);
        System.out.println("a-t meglopja b");
        v1.lopas(v2, new Zsak());
        System.out.println("Lopas sikertelensegenek ellenorzese...");
        System.out.println(v2.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt b szempontjabol." : "A lopas sikeres volt b szempontjabol.");
        System.out.println(!v1.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt a szempontjabol." : "A lopas sikeres volt a szempontjabol.");

    }

    // [15]
    public void sikeresLopasZsakkal(){
        Virologus v1 = new Virologus();
        v1.setNev("a");
        Virologus v2 = new Virologus();
        v2.setNev("b");
        System.out.println("Lopando felszereles letrehozasa, tarolasa 'b' altal...");
        var lopando = new Zsak();
        lopando.getTar().Tarolas(new Aminosav(42));
        System.out.println("Zsak letrehozasa, es 'b'-re kenese...");
        v2.getAktivModositok().add(new Benulas(20));
        v2.getAktivVedofelszerelesek().add(lopando);
        System.out.println("a-t meglopja b");
        v1.lopas(v2, lopando);
        System.out.println("Lopas sikeressegenek ellenorzese...");
        System.out.println(v2.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt b szempontjabol." : "A lopas sikeres volt b szempontjabol.");
        System.out.println(!v1.getAktivVedofelszerelesek().contains(lopando)? "A lopas sikertelen volt a szempontjabol." : "A lopas sikeres volt a szempontjabol.");

        System.out.println("Zsak anyagainak hasznalata...");

        var res = v1.anyagFelhasznalasa(new Aminosav(40));

        System.out.println("A zsakkal szerzett anyag felhasznalasa "+( res == null ? "sikertelen" : "sikeres") + " volt.");

    }
    //endregion
    //region oregedes
    /**
     * Minden agens oregedeseert a super class felelős, ezert egyszer tesztelve
     * */
    public void agensOregedese(){
        System.out.println("A mozgas tesztjenek megfelelo kornyezet letrehozasa...");
        var v1 = createAliceAndThreeFields();
        Raktar cel = (Raktar) v1.getJelenlegiMezo().getSzomszedok().stream().filter(p-> p instanceof Raktar).findFirst().get();
        System.out.println("Benulas hozzaadasa egy (1) kor elettartammal...");
        var benulas = new Benulas(1);
        v1.getAktivModositok().add(benulas);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");
        System.out.println("Mozgas a raktarba....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");
        System.out.println("Benulas oregitese (lejar)");
        benulas.onTickReceived(1);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");
        System.out.println("Mozgas a raktarba....");
        v1.mozgas(cel);
        System.out.println("A jelenlegi mezo "+ (v1.getJelenlegiMezo() instanceof Raktar ? "valoban" : "nem") + " Raktar.");
    }
    //endregion


}
